#pragma once
#include "Common.h"
void AppIO_out(char* aMessage);	//���
int AppIO_in_order(void);	//�Է�
