#include "Common.h"
#include "MagicSquare.h"
#include "AppIO.h"
#include <stdio.h>
#include "AppController.h"
#include "MagicSquare.h"
int main(int argc, const char* argv[]) {
	AppController *appController;
	appController = AppController_new();
	AppController_run(appController);
	AppController_delete(appController);
	return 0;
}
